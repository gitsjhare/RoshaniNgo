import {Component} from '@angular/core';
//import * as $ from 'jquery';
//import * as Data from '../../assets/data/gallery.json';

@Component({
    selector:'Roshani-Gallery',
    templateUrl:'./app.gallery.component.html',
    styleUrls:['./app.gallery.component.scss']
})

export class Gallery {
    
}