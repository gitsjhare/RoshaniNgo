import { Component,OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';
//import {YearAndJsonFilePath} from './app.press.components.interface';



@Component({
    selector: 'Roshani-Press',
    templateUrl: './app.press.component.html',
    styleUrls: ['./app.press.component.scss']
})


export class Press implements OnInit {
   
    public Years: any;
    public YearlyUrl: any;    
    public GallaryArray:any[]=[];
    public Gallery:any;
    constructor(private http: Http) {        
    }
    ngOnInit(): void {
        this.http.get("/assets/data/pressyears.json")
            .map((res: Response) => res.json())
            .subscribe(res=>{
                this.Years=res
               // this.render()
            },
            err=>console.log(err),
            ()=>console.log("Complete")
        );
    }
   
   
}