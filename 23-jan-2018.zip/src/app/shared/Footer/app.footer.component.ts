import { Component } from '@angular/core';

@Component({
  selector: 'Footer-Roshani',  
  templateUrl: './app.footer.component.html',
  styleUrls: ['./app.footer.component.scss']
})
export class FooterComponent {
  Roshani='Roshani';
}