export interface YearAndJsonFilePath{
year:string;
gallarypath:string;
}