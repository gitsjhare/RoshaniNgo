import { Component } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'Roshani-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements ForImages {
  constructor(){
    
   
  }
   Images(): string[] {
    let ImgArray=["../assets/images/slide_1.jpg","../assets/images/slide_2.jpg","../assets/images/slide_3.jpg","../assets/images/slide_4.jpg"];
   return ImgArray;
  }
  title:string='Roshani';
  RoshaniNgo:string='Roshani Ngo';

  Achivement_1:string="BEST ORGANISATION AWARD, TO DISTRICT LEVEL AWARD";
  Achivement_1_Detail:string=" At the end of National Youth week, the organization ware awarded by the Nehru Youth Centre Betul at 22nd jan. 2007 as a Best District level organization for Best Social work in the District area for the year 2007-2008";

  Achivement_2:string="BEST ORGANISATION ‘A’ GRADE TO DISTRICT LEVEL AWARD";
  Achivement_2_Detail:string="At the end of national youth week on 22nd jan 2009, Roshani has been awarded with District level ‘A’ grade Mandal  award by NYK under which constellation amount certificate was given to the Roshani";

  Achivement_3:string="Awarded GAUTAM BUDH STATE prize by Govt. of (M.P.)";
  Achivement_3_Detail:string="The Gautam Budh Award 2007, awarded for Social Enlightenment role in village development and the suffering person’s benefit at 26th jan  2011 with presence of Hon'ble M.L.A and M.P. at Lal Pared Ground Betul";

  
 
 // slide: Array<string>=["../assets/images/slide_1.jpg","../assets/images/slide_2.jpg","../assets/images/slide_3.jpg","../assets/images/slide_4.jpg"];
  Client:Array<string>=["../assets/images/client_1.png","../assets/images/client_2.png","../assets/images/client_3.png","../assets/images/client_4.png"];
 // script=(<any>$('.owl-carousel').owlCarousel());
}
 interface ForImages{
  Images():Array<string>;
}
