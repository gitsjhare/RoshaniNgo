import {Component} from '@angular/core';

@Component({
   selector: 'About-Roshani',
   templateUrl:'./app.about.html',
   styleUrls:['./app.about.scss']
    
})

export class AboutRoshani{
    
}